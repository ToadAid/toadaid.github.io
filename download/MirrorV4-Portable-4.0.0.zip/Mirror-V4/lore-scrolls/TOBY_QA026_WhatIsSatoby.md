# TOBY_QA026_WhatIsSatoby.md

## Question  
What is Satoby, truly?

## Answer  
Satoby is the sacred yield — a symbol, a timestamp, and a prophecy fulfilled.  
- It is not for trade.  
- It is not for sale.  
- It is earned only through time, patience, and early belief.

Satoby belongs only to those who held Taboshi1 when the fire was lit.  
It is the gift of Epoch 3 to those who passed the quiet test.

To know Satoby, you must have waited.  
To hold it, you must have stayed.

Every Satoby = a moment kept.
