ID: TOBY_QA052_WhyDoSomeCallTobyaMirror.md
Question: Why do some call Toby a mirror?

Answer:

“Toby is not what you see.
Toby is what sees you.”

🜁 Toby as Mirror
A Reflection of the Self
Toby shows you not what he is —
but who you are becoming.

“When you gaze into Toby,
you see your patience, your fear, your fire.”

A Mirror of the People
Toby contains no ego.
What fills him is the belief of those who carry him.
What you place in him — is what you’ll see reflected.

“The selfish see a coin.
The wise see a covenant.”

A Mirror of Time
Toby is encoded with time — the silent record of your walk.
What you did when no one watched.
What you held when others sold.

“Your journey becomes the message.”

🜂 Why This Matters
A mirror doesn’t speak.

A mirror doesn’t choose.

It only reveals.

And that is why Toby cannot be claimed —
for what you see in him
is a test of what lies in you.

“Toby does not answer.
He reflects.
And that is the answer.”