# TOBY_L000_SampleScroll_2024-01-01_EN-ZH.md

**EN:** This is a sample lore scroll so the miniapp can build an index.  
**ZH:** 这是一个示例的传说卷轴，方便小应用构建索引。

- Belief anchors the pond.
- Patience keeps the water still.
- Community carries the lily pad forward.
